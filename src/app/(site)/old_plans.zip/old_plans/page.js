// src/app/(site)/old_plans/page.js

import OldPlansClient from "./component/OldPlansClient";

export const metadata = {
  title: "Old Plans — Skylink",
  description: "View all archived and previous broadband plans from Skylink.",
};

export default function Page() {
  return <OldPlansClient />;
}
