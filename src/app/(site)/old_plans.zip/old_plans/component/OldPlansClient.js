"use client";

import React, { useState, useEffect, useRef } from "react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import dynamic from "next/dynamic";
import Tab from "./component/Tab";
import { Providers } from "../Providers";
import { PlanProvider } from "./context/PlansContext";

const ReactSelectWithSearch = dynamic(
  () => import("@/components/SelectField"),
  { ssr: false }
);

const Drawyer = dynamic(() => import("@/components/Drawyer"));

export default function OldPlansClient() {
  return (
    <Providers>
      <PlanProvider>
        <Tab />
      </PlanProvider>
    </Providers>
  );
}
